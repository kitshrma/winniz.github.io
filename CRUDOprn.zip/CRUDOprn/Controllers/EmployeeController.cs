﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CRUDOprn.Models;
namespace CRUDOprn.Controllers
{
    public class EmployeeController : Controller
    {

        static List<EmployeeDetails> lstDetails = new List<EmployeeDetails>();
        // GET: Employee
        [HttpGet]

        public ActionResult Index()
        {
            EmployeeDetails emp = new EmployeeDetails();
            if ((List<EmployeeDetails>)TempData["lstempDetails"] != null || lstDetails.Count() > 0)
            {
                emp.lstempDetails = (List<EmployeeDetails>)TempData["lstempDetails"];
                emp.lstempDetails = lstDetails;
            }
            return View(emp);


        }

        [HttpPost]

        public ActionResult Index(EmployeeDetails eDetails)
        {
             

            if (string.IsNullOrEmpty(eDetails.firstName))
                ModelState.AddModelError("firstName", "FirstName is required");

            if (string.IsNullOrEmpty(eDetails.lastName))
                ModelState.AddModelError("lastName", "LastName is required");

            if (string.IsNullOrEmpty(eDetails.gender))
                ModelState.AddModelError("gender", "Gender is required");

            if (string.IsNullOrEmpty(Convert.ToString(eDetails.age)) && eDetails.age <= 0)
                ModelState.AddModelError("age", "Enter Valid Age");


            if (ModelState.IsValid)
            {
                EmployeeDetails e = lstDetails.Where(x => x.id == eDetails.id).FirstOrDefault();
                if (e != null)
                {
                    e.firstName = eDetails.firstName;
                    e.lastName = eDetails.lastName;
                    e.gender = eDetails.gender;
                    e.age = eDetails.age;

                    TempData["lstempDetails"] = lstDetails;
                }
                else
                {
                    if (lstDetails.Count() > 0)
                        eDetails.id = lstDetails.Select(x => x.id).LastOrDefault() + 1;
                    else
                        eDetails.id = 1;

                    lstDetails.Add(eDetails);
                    TempData["lstempDetails"] = lstDetails;
                }




                return RedirectToAction("Index");
            }

            else
            { eDetails.lstempDetails = lstDetails; return View(eDetails); }
        }

        public ActionResult Edit ( int id)
        {
            EmployeeDetails e = lstDetails.Where(x => x.id == id).FirstOrDefault();
            if (e != null)
            { e.lstempDetails = lstDetails; return View("Index", e); }
            else
                return View("Index", new EmployeeDetails());
        }


        public ActionResult Details(int id)
        {
            EmployeeDetails e = lstDetails.Where(x => x.id == id).FirstOrDefault();
            if (e != null)
            { e.lstempDetails = lstDetails; TempData["lstempDetails"] = lstDetails; return View(e); }
            else
                return View(new EmployeeDetails());
        }


        public ActionResult Delete (int id)
        {
            EmployeeDetails e = lstDetails.Where(x => x.id == id).FirstOrDefault();
            if (e != null)
            {
                lstDetails.Remove(e);
                TempData["lstempDetails"] = lstDetails;
            }

            return RedirectToAction("Index");
        }
    }
}