﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace CRUDOprn.Models
{
    public class EmployeeDetails
    {
        public int id { get; set; }

        [Display(Name ="First Name")]
        public string firstName { get; set; }
        [Display(Name = "Last Name")]
        public string lastName { get; set; }
        [Display(Name = "Gender")]
        public string gender { get; set; }
        [Display(Name = "Age")]
        public int age { get; set; }

        public List<EmployeeDetails> lstempDetails { get; set; }

        public EmployeeDetails()
        {
            lstempDetails = new List<EmployeeDetails>();
        }

    }
   
}