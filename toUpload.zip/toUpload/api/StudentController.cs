﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using CrudOperation.Models;
namespace CrudOperation.api
{

    public class StudentController : ApiController
    {
        StudentDBEntities context = new StudentDBEntities();

        [HttpPost]
        public HttpResponseMessage SaveStudent (Student s)
        {
            int result = 0;
            try
            {
                context.Students.Add(s);
                context.SaveChanges();
                result = 1;
            }
            catch(Exception e)
            {
                result = 0;
            }
            
            return Request.CreateResponse(HttpStatusCode.OK, result);
        }

        [HttpGet]
        public List<Student> GetStudents()
        {
            return context.Students.ToList();
        }
    }
}
