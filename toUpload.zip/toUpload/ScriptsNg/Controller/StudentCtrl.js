﻿app.controller('StudentCtrl', ['$scope', 'CrudService', function ($scope, CrudService) {

    $scope.message = "Hi";
    var baseUrl = "/api/Student/";
    $scope.btnText = "Save";
    $scope.stuId = 0;
    $scope.SaveStudent = function () {
        var student = {
            FirstName: $scope.firstName,
            LastName: $scope.lastName,
            Gender: $scope.gender
        };

        if ($scope.btnText == "Save") {
            var apiRoute = baseUrl + 'SaveStudent/';
            var saveStudent = CrudService.post(apiRoute, student);
            saveStudent.then(function (response) {
                if (response.data != "") {
                    alert("Data Saved Successfully");
                    $scope.Clear();
                    $scope.GetStudents();
                }
                else
                    alert("Some Error");

            }, function (error) {
                console.log("Error: " + error);
            })
        }
    };
    $scope.Clear = function () {
        $scope.stuId = 0;
        $scope.firstName = "";
        $scope.lastName = "";
        $scope.gender = "";
        
    };

    $scope.GetStudents = function()
    {
        var apiRoute = baseUrl + 'GetStudents/';
        var student = CrudService.getAll(apiRoute);
        student.then(function (response) {
            $scope.students = response.data;
        }, function (error) {

            console.log("Error: " + error);
        });
    }

    $scope.GetStudents();
}]);