﻿app.service('CrudService', function ($http) {

    var urlGet = '';
    this.post = function (route, studata) {
        var request = $http({

            method: 'post',
            url: route,
            data: studata
        });

        return request;
    };

    this.getAll = function(apiRoute)
    {
        var result = $http({

            method: 'get',
            url: apiRoute
        });

        return result;
    }

});